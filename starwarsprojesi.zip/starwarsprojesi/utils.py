import pygame
from collections import deque
import random

def bfs(baslangic, hedef, labirent, max_derinlik=100):
    """
    Breadth-first search algoritması ile en kısa yolu bulan fonksiyon
    """
    # Matris boyutları
    yukseklik = len(labirent)
    genislik = len(labirent[0])
    
    # Hareket yönleri (yukarı, sağ, aşağı, sol)
    yonler = [(-1, 0), (0, 1), (1, 0), (0, -1)]
    
    # Başlangıç ve hedef konumlar
    if isinstance(baslangic, tuple):
        baslangic_y, baslangic_x = baslangic
    else:
        baslangic_y, baslangic_x = baslangic.y, baslangic.x
        
    if isinstance(hedef, tuple):
        hedef_y, hedef_x = hedef
    else:
        hedef_y, hedef_x = hedef.y, hedef.x
    
    # Ziyaret edilmiş hücreleri takip etmek için
    ziyaret_edildi = [[False for _ in range(genislik)] for _ in range(yukseklik)]
    ziyaret_edildi[baslangic_y][baslangic_x] = True
    
    # BFS için sıra
    kuyruk = deque([(baslangic_y, baslangic_x, [])])
    
    while kuyruk and max_derinlik > 0:
        y, x, yol = kuyruk.popleft()
        max_derinlik -= 1
        
        # Hedefe ulaştık mı?
        if y == hedef_y and x == hedef_x:
            return yol
        
        # Tüm yönlerde hareket et
        for dy, dx in yonler:
            ny, nx = y + dy, x + dx
            
            # Sınırlar içinde mi ve geçilebilir mi?
            if 0 <= ny < yukseklik and 0 <= nx < genislik and labirent[ny][nx] == 1 and not ziyaret_edildi[ny][nx]:
                ziyaret_edildi[ny][nx] = True
                yeni_yol = yol + [(ny, nx)]
                kuyruk.append((ny, nx, yeni_yol))
    
    # Yol bulunamadı
    return []

def dusman_hareket(dusman, oyuncu_konum, labirent):
    """
    Düşman karakterlerin hareket etmesini sağlayan fonksiyon
    """
    try:
        # Rastgele hareket edecek
        if random.random() < 0.3:  # %30 ihtimalle rastgele hareket
            yonler = [(-1, 0), (0, 1), (1, 0), (0, -1)]
            random.shuffle(yonler)
            
            for dy, dx in yonler:
                if not hasattr(dusman.konum, 'x') or not hasattr(dusman.konum, 'y'):
                    return
                    
                ny, nx = dusman.konum.y + dy, dusman.konum.x + dx
                if 0 <= ny < len(labirent) and 0 <= nx < len(labirent[0]) and labirent[ny][nx] == 1:
                    dusman.konumAyarla((nx, ny))
                    return
        else:
            # Kendi enKisaYol metodu varsa kullan, yoksa genel BFS'yi kullan
            if hasattr(dusman, 'enKisaYol'):
                yol = dusman.enKisaYol(oyuncu_konum, labirent)
            else:
                yol = bfs(dusman.konum, oyuncu_konum, labirent, max_derinlik=10)
                
            if yol and len(yol) > 0:
                # İlk adımı at
                dusman.konumAyarla(yol[0])
    except Exception as e:
        print(f"Düşman hareketi sırasında hata: {e}")

def oyunu_ciz(ekran, labirent, oyuncu, dusmanlar, kupa_konum):
    """
    Oyun ekranını çizen fonksiyon
    """
    # Ekran boyutları
    ekran_genislik, ekran_yukseklik = ekran.get_size()
    
    # Labirent hücre boyutları
    hucre_genislik = ekran_genislik // len(labirent[0])
    hucre_yukseklik = ekran_yukseklik // len(labirent)
    
    # Labirenti çiz
    for y in range(len(labirent)):
        for x in range(len(labirent[0])):
            dikdortgen = pygame.Rect(x * hucre_genislik, y * hucre_yukseklik, hucre_genislik, hucre_yukseklik)
            if labirent[y][x] == 1:  # Geçilebilir hücre
                pygame.draw.rect(ekran, (200, 200, 200), dikdortgen)
            else:  # Duvar
                pygame.draw.rect(ekran, (50, 50, 50), dikdortgen)
            
            # Hücre sınırlarını çiz
            pygame.draw.rect(ekran, (100, 100, 100), dikdortgen, 1)
    
    # Kupayı çiz
    kupa_dikdortgen = pygame.Rect(kupa_konum[0] * hucre_genislik, kupa_konum[1] * hucre_yukseklik, hucre_genislik, hucre_yukseklik)
    pygame.draw.rect(ekran, (255, 215, 0), kupa_dikdortgen)  # Altın sarısı
    
    # Oyuncuyu çiz
    oyuncu_dikdortgen = pygame.Rect(oyuncu.konum.x * hucre_genislik, oyuncu.konum.y * hucre_yukseklik, hucre_genislik, hucre_yukseklik)
    if isinstance(oyuncu.ad, str) and "Luke" in oyuncu.ad:
        pygame.draw.rect(ekran, (0, 0, 255), oyuncu_dikdortgen)  # Mavi
    else:  # Yoda
        pygame.draw.rect(ekran, (0, 255, 0), oyuncu_dikdortgen)  # Yeşil
    
    # Düşmanları çiz
    for dusman in dusmanlar:
        dusman_dikdortgen = pygame.Rect(dusman.konum.x * hucre_genislik, dusman.konum.y * hucre_yukseklik, hucre_genislik, hucre_yukseklik)
        pygame.draw.rect(ekran, (255, 0, 0), dusman_dikdortgen)  # Kırmızı
    
    # Oyuncu can bilgisini göster
    yazi_tipi = pygame.font.SysFont(None, 36)
    yazi = yazi_tipi.render(f"Can: {oyuncu.canGetir()}", True, (255, 255, 255))
    ekran.blit(yazi, (10, 10))

def oyun_sonu_goster(ekran):
    """
    Oyun sonu ekranı (kaybetme)
    """
    ekran.fill((0, 0, 0))
    yazi_tipi = pygame.font.SysFont(None, 72)
    yazi = yazi_tipi.render("GAME OVER", True, (255, 0, 0))
    yazi_dikdortgen = yazi.get_rect(center=(ekran.get_width() // 2, ekran.get_height() // 2))
    ekran.blit(yazi, yazi_dikdortgen)
    pygame.display.flip()
    
    # 3 saniye bekle
    pygame.time.wait(3000)

def zafer_goster(ekran):
    """
    Oyun sonu ekranı (kazanma)
    """
    ekran.fill((0, 0, 0))
    yazi_tipi = pygame.font.SysFont(None, 72)
    yazi = yazi_tipi.render("ZAFER!", True, (0, 255, 0))
    yazi_dikdortgen = yazi.get_rect(center=(ekran.get_width() // 2, ekran.get_height() // 2))
    ekran.blit(yazi, yazi_dikdortgen)
    pygame.display.flip()
    
    # 3 saniye bekle
    pygame.time.wait(3000)

def ses_cal(ses_dosyasi):
    """
    Ses efekti çalan fonksiyon
    """
    try:
        pygame.mixer.Sound(ses_dosyasi).play()
    except:
        pass  # Ses dosyası bulunamazsa hata verme 