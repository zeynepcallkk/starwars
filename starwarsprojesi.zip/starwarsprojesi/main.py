# -*- coding: utf-8 -*-
# Labirent Tabanlı OOP + Veri Yapıları + Yol Bulma Oyunu
# Programlama Dili: Python
# Grafik Arayüz: pygame

import pygame
import sys
import random
from collections import deque
from harita import Harita
from karakterler import LukeSkywalker, MasterYoda, Stormtrooper, DarthVader, KyloRen
from utils import bfs, dusman_hareket, oyunu_ciz, oyun_sonu_goster, zafer_goster, ses_cal

# --- Oyun Sabitleri ---
KARE_BOYUTU = 64
HARITA_SATIRLAR, HARITA_SUTUNLAR = 11, 14
PENCERE_GENISLIK = KARE_BOYUTU * HARITA_SUTUNLAR
PENCERE_YUKSEKLIK = KARE_BOYUTU * HARITA_SATIRLAR
FPS = 10

# --- Renkler ---
BEYAZ = (255, 255, 255)
SIYAH = (0, 0, 0)
GRI = (100, 100, 100)
SARI = (255, 255, 0)
MAVI = (0, 0, 255)
KIRMIZI = (255, 0, 0)
YESIL = (0, 255, 0)

# Pygame başlat
pygame.init()
saat = pygame.time.Clock()
ekran = pygame.display.set_mode((1000, 600))
pygame.display.set_caption("Yıldız Savaşları: Labirent Kaçışı")

# Haritayı yükle
harita = Harita("harita.txt")
harita_yolu = harita.labirent
kotu_karakterler = harita.kotu_karakterler
kupa_koordinat = harita.kupa_konum

# Zorluk seviyeleri
def zorluk_seviyesi():
    ekran.fill((0, 0, 0))
    yazi_tipi = pygame.font.SysFont(None, 48)
    yazi1 = yazi_tipi.render("1: Kolay", True, (255, 255, 255))
    yazi2 = yazi_tipi.render("2: Orta", True, (255, 255, 255))
    yazi3 = yazi_tipi.render("3: Zor", True, (255, 255, 255))
    ekran.blit(yazi1, (150, 200))
    ekran.blit(yazi2, (150, 260))
    ekran.blit(yazi3, (150, 320))
    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return "Kolay"
                elif event.key == pygame.K_2:
                    return "Orta"
                elif event.key == pygame.K_3:
                    return "Zor"

# Menü ekranı
def ana_menu():
    ekran.fill((0, 0, 0))
    yazi_tipi = pygame.font.SysFont(None, 48)
    yazi1 = yazi_tipi.render("Yıldız Savaşları: Labirent Kaçışı", True, (255, 255, 255))
    yazi2 = yazi_tipi.render("Başlamak için ENTER'a basın", True, (255, 255, 255))
    ekran.blit(yazi1, (150, 200))
    ekran.blit(yazi2, (150, 260))
    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return True

# Karakter Seçimi
def karakter_secimi():
    oyuncu = None
    while not oyuncu:
        ekran.fill((0, 0, 0))
        yazi_tipi = pygame.font.SysFont(None, 48)
        yazi1 = yazi_tipi.render("1: Luke Skywalker (3 can)", True, (255, 255, 255))
        yazi2 = yazi_tipi.render("2: Master Yoda (6 yarım can)", True, (255, 255, 255))
        ekran.blit(yazi1, (150, 200))
        ekran.blit(yazi2, (150, 260))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    oyuncu = LukeSkywalker("Luke Skywalker", "iyi", harita.baslangic)
                elif event.key == pygame.K_2:
                    oyuncu = MasterYoda("Master Yoda", "iyi", harita.baslangic)
    return oyuncu

# Oyun Döngüsü
def oyun_dongusu():
    # Zorluk seviyesini seç
    zorluk = zorluk_seviyesi()
    
    # Ana menüyü göster
    ana_menu()
    
    # Karakter seçimi
    oyuncu = karakter_secimi()
    
    # Oyun değişkenleri
    oyun_bitti = False
    kazandi = False
    
    # Düşman hareket hızını zorluk seviyesine göre ayarla
    hareket_zamani = 0
    hareket_aralik = 1000  # milisaniye
    if zorluk == "Kolay":
        hareket_aralik = 1500
    elif zorluk == "Orta":
        hareket_aralik = 1000
    else:  # Zor
        hareket_aralik = 500
    
    son_zaman = pygame.time.get_ticks()
    
    while not oyun_bitti and not kazandi:
        ekran.fill((0, 0, 0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        
        # Oyuncu hareketi (ok tuşları)
        tuslar = pygame.key.get_pressed()
        dx, dy = 0, 0
        if tuslar[pygame.K_UP]:
            dy = -1
        elif tuslar[pygame.K_DOWN]:
            dy = 1
        elif tuslar[pygame.K_LEFT]:
            dx = -1
        elif tuslar[pygame.K_RIGHT]:
            dx = 1
        
        yeni_x = oyuncu.konum.x + dx
        yeni_y = oyuncu.konum.y + dy
        if 0 <= yeni_y < len(harita_yolu) and 0 <= yeni_x < len(harita_yolu[0]):
            if harita_yolu[yeni_y][yeni_x] == 1:
                oyuncu.konumAyarla((yeni_x, yeni_y))
        
        # Zaman bazlı düşman hareketi
        simdiki_zaman = pygame.time.get_ticks()
        if simdiki_zaman - son_zaman > hareket_aralik:
            # Düşman hareketi ve çarpışma kontrolü
            for dusman in kotu_karakterler:
                dusman_hareket(dusman, oyuncu.konum, harita_yolu)
                if dusman.konum == oyuncu.konum:
                    # Çarpışma oldu, can azalt
                    print("Çarpışma oldu! {} hasar alıyor...".format(oyuncu.ad))
                    if isinstance(oyuncu, MasterYoda):
                        # Yoda yarım can kaybeder
                        oyuncu.canAzalt()
                        if oyuncu.canGetir() <= 0:
                            oyun_bitti = True
                    else:
                        # Luke tam can kaybeder
                        oyuncu.canAzalt()
                        if oyuncu.canGetir() <= 0:
                            oyun_bitti = True
            son_zaman = simdiki_zaman
        
        # Kupa kontrolü
        if oyuncu.konum == kupa_koordinat:
            kazandi = True
            print("🎉 Oyuncu kupaya ulaştı! Oyunu kazandınız!")
        
        # Çizim
        oyunu_ciz(ekran, harita_yolu, oyuncu, kotu_karakterler, kupa_koordinat)
        
        pygame.display.update()
        saat.tick(FPS)
    
    # Oyun Sonu
    if oyun_bitti:
        oyun_sonu_goster(ekran)
    elif kazandi:
        zafer_goster(ekran)
    
    pygame.quit()

# Oyunu başlat
if __name__ == "__main__":
    oyun_dongusu()









