class Harita:
    def __init__(self, harita_dosyasi=None):
        self.kotu_karakterler = []
        self.labirent = []
        self.baslangic = None
        self.kupa_konum = None
        
        if harita_dosyasi:
            self.harita_yukle(harita_dosyasi)
        else:
            # Varsayılan harita verileri
            self.karakter_A = "Stormtrooper"
            self.kapi_A = "A"
            self.karakter_B = "Stormtrooper"
            self.kapi_B = "B"
            
            # Varsayılan haritayı yükle
            self.labirent = [
                [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0],
                [0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0],
                [0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0],
                [0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0],
                [0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0],
                [1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1],
                [0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0],
                [0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0],
                [0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0],
                [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ]
            # Varsayılan başlangıç pozisyonu ve kupa konumunu ayarla
            self.baslangic = (1, 1)
            self.kupa_konum = (12, 9)
            
            # Varsayılan düşmanları ekle
            from karakterler import Stormtrooper
            self.kotu_karakterler = [
                Stormtrooper("Stormtrooper A", "kotu", (4, 0)),
                Stormtrooper("Stormtrooper B", "kotu", (12, 0))
            ]
    
    def harita_yukle(self, dosya_adi):
        try:
            with open(dosya_adi, 'r') as dosya:
                satirlar = dosya.readlines()
                
                # İlk satırlardan karakter bilgilerini ayıkla
                karakter_bilgileri = []
                harita_baslangic_satiri = 0
                
                for i, satir in enumerate(satirlar):
                    if satir.startswith("Karakter:"):
                        parcalar = satir.strip().split(',')
                        karakter_bilgisi = {}
                        for parca in parcalar:
                            anahtar, deger = parca.split(':')
                            karakter_bilgisi[anahtar] = deger
                        karakter_bilgileri.append(karakter_bilgisi)
                        harita_baslangic_satiri = i + 1
                    else:
                        break
                
                # Harita verilerini ayıkla
                self.labirent = []
                for i in range(harita_baslangic_satiri, len(satirlar)):
                    if satirlar[i].strip():
                        satir = [int(hucre) for hucre in satirlar[i].strip().split()]
                        self.labirent.append(satir)
                
                # Varsayılan başlangıç ve kupa pozisyonlarını ayarla
                self.baslangic = (1, 1)
                self.kupa_konum = (12, 9)
                
                # Düşman karakterleri oluştur
                from karakterler import Stormtrooper
                self.kotu_karakterler = []
                for karakter_bilgisi in karakter_bilgileri:
                    if karakter_bilgisi.get("Karakter") == "Stormtrooper":
                        pozisyon = (4, 0) if karakter_bilgisi.get("Kapi") == "A" else (12, 0)
                        self.kotu_karakterler.append(
                            Stormtrooper(f"Stormtrooper {karakter_bilgisi.get('Kapi')}", "kotu", pozisyon)
                        )
        except Exception as e:
            print(f"Harita yüklenirken hata: {e}")
            # Varsayılan haritayı yükle
            self.__init__()
