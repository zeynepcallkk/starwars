class Konum:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __eq__(self, other):
        if isinstance(other, tuple) and len(other) == 2:
            return self.x == other[0] and self.y == other[1]
        if isinstance(other, Konum):
            return self.x == other.x and self.y == other.y
        return False

class Karakter:
    def __init__(self, ad, tur, konum):
        self.ad = ad
        self.tur = tur
        if isinstance(konum, tuple) and len(konum) == 2:
            self.konum = Konum(konum[0], konum[1])
        else:
            self.konum = konum
    
    def konumAyarla(self, konum):
        if isinstance(konum, tuple) and len(konum) == 2:
            self.konum = Konum(konum[0], konum[1])
        else:
            self.konum = konum
    
    def konumGetir(self):
        return self.konum

class KotuKarakter(Karakter):
    def __init__(self, ad, tur, konum):
        super().__init__(ad, tur, konum)

class Stormtrooper(KotuKarakter):
    def __init__(self, ad, tur, konum):
        super().__init__(ad, tur, konum)
        self.hiz = 1
    
    def enKisaYol(self, hedef, harita):
        # Standart BFS algoritması
        from collections import deque
        
        # Başlangıç ve hedef konumlar
        if hasattr(self.konum, 'x') and hasattr(self.konum, 'y'):
            baslangic_x, baslangic_y = self.konum.x, self.konum.y
        else:
            # Eğer konum bir tuple ise
            baslangic_x, baslangic_y = self.konum[0], self.konum[1]
            
        if isinstance(hedef, tuple):
            hedef_x, hedef_y = hedef
        elif hasattr(hedef, 'x') and hasattr(hedef, 'y'):
            hedef_x, hedef_y = hedef.x, hedef.y
        else:
            return []
            
        # Matris boyutları
        yukseklik = len(harita)
        genislik = len(harita[0])
        
        # Kontrol et: başlangıç ve hedef noktaları harita sınırları içinde mi?
        if not (0 <= baslangic_y < yukseklik and 0 <= baslangic_x < genislik):
            return []
        if not (0 <= hedef_y < yukseklik and 0 <= hedef_x < genislik):
            return []
        
        # Hareket yönleri (yukarı, sağ, aşağı, sol)
        yonler = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        
        # Ziyaret edilmiş hücreleri takip etmek için
        ziyaret_edildi = [[False for _ in range(genislik)] for _ in range(yukseklik)]
        ziyaret_edildi[baslangic_y][baslangic_x] = True
        
        # BFS için sıra
        kuyruk = deque([(baslangic_y, baslangic_x, [])])
        
        while kuyruk:
            y, x, yol = kuyruk.popleft()
            
            # Hedefe ulaştık mı?
            if x == hedef_x and y == hedef_y:
                return yol + [(x, y)]
            
            # Tüm yönlerde hareket et
            for dy, dx in yonler:
                ny, nx = y + dy, x + dx
                
                # Sınırlar içinde mi ve geçilebilir mi?
                if 0 <= ny < yukseklik and 0 <= nx < genislik and harita[ny][nx] == 1 and not ziyaret_edildi[ny][nx]:
                    ziyaret_edildi[ny][nx] = True
                    yeni_yol = yol + [(x, y)]
                    kuyruk.append((ny, nx, yeni_yol))
        
        # Yol bulunamadı
        return []

class DarthVader(KotuKarakter):
    def __init__(self, ad, tur, konum):
        super().__init__(ad, tur, konum)
        self.hiz = 2
    
    def enKisaYol(self, hedef, harita):
        # Duvarları görmezden gelen BFS algoritması
        from collections import deque
        
        # Başlangıç ve hedef konumlar
        if hasattr(self.konum, 'x') and hasattr(self.konum, 'y'):
            baslangic_x, baslangic_y = self.konum.x, self.konum.y
        else:
            # Eğer konum bir tuple ise
            baslangic_x, baslangic_y = self.konum[0], self.konum[1]
            
        if isinstance(hedef, tuple):
            hedef_x, hedef_y = hedef
        elif hasattr(hedef, 'x') and hasattr(hedef, 'y'):
            hedef_x, hedef_y = hedef.x, hedef.y
        else:
            return []
            
        # Matris boyutları
        yukseklik = len(harita)
        genislik = len(harita[0])
        
        # Kontrol et: başlangıç ve hedef noktaları harita sınırları içinde mi?
        if not (0 <= baslangic_y < yukseklik and 0 <= baslangic_x < genislik):
            return []
        if not (0 <= hedef_y < yukseklik and 0 <= hedef_x < genislik):
            return []
        
        # Hareket yönleri (yukarı, sağ, aşağı, sol)
        yonler = [(-1, 0), (0, 1), (1, 0), (0, -1)]
        
        # Ziyaret edilmiş hücreleri takip etmek için
        ziyaret_edildi = [[False for _ in range(genislik)] for _ in range(yukseklik)]
        ziyaret_edildi[baslangic_y][baslangic_x] = True
        
        # BFS için sıra
        kuyruk = deque([(baslangic_y, baslangic_x, [])])
        
        while kuyruk:
            y, x, yol = kuyruk.popleft()
            
            # Hedefe ulaştık mı?
            if x == hedef_x and y == hedef_y:
                return yol + [(x, y)]
            
            # Tüm yönlerde hareket et
            for dy, dx in yonler:
                ny, nx = y + dy, x + dx
                
                # Sınırlar içinde mi? Duvarları görmezden geliyoruz
                if 0 <= ny < yukseklik and 0 <= nx < genislik and not ziyaret_edildi[ny][nx]:
                    ziyaret_edildi[ny][nx] = True
                    yeni_yol = yol + [(x, y)]
                    kuyruk.append((ny, nx, yeni_yol))
        
        # Yol bulunamadı
        return []

class KyloRen(KotuKarakter):
    def __init__(self, ad, tur, konum):
        super().__init__(ad, tur, konum)
        self.hiz = 1.5
    
    def enKisaYol(self, hedef, harita):
        # İki adım birden giden BFS algoritması
        from collections import deque
        
        # Başlangıç ve hedef konumlar
        if hasattr(self.konum, 'x') and hasattr(self.konum, 'y'):
            baslangic_x, baslangic_y = self.konum.x, self.konum.y
        else:
            # Eğer konum bir tuple ise
            baslangic_x, baslangic_y = self.konum[0], self.konum[1]
            
        if isinstance(hedef, tuple):
            hedef_x, hedef_y = hedef
        elif hasattr(hedef, 'x') and hasattr(hedef, 'y'):
            hedef_x, hedef_y = hedef.x, hedef.y
        else:
            return []
            
        # Matris boyutları
        yukseklik = len(harita)
        genislik = len(harita[0])
        
        # Kontrol et: başlangıç ve hedef noktaları harita sınırları içinde mi?
        if not (0 <= baslangic_y < yukseklik and 0 <= baslangic_x < genislik):
            return []
        if not (0 <= hedef_y < yukseklik and 0 <= hedef_x < genislik):
            return []
        
        # Hareket yönleri (yukarı, sağ, aşağı, sol)
        yonler = [(-2, 0), (0, 2), (2, 0), (0, -2)]  # İki adım birden
        
        # Ziyaret edilmiş hücreleri takip etmek için
        ziyaret_edildi = [[False for _ in range(genislik)] for _ in range(yukseklik)]
        ziyaret_edildi[baslangic_y][baslangic_x] = True
        
        # BFS için sıra
        kuyruk = deque([(baslangic_y, baslangic_x, [])])
        
        while kuyruk:
            y, x, yol = kuyruk.popleft()
            
            # Hedefe ulaştık mı?
            if x == hedef_x and y == hedef_y:
                return yol + [(x, y)]
            
            # Tüm yönlerde hareket et
            for dy, dx in yonler:
                ny, nx = y + dy, x + dx
                
                # Sınırlar içinde mi ve geçilebilir mi?
                if 0 <= ny < yukseklik and 0 <= nx < genislik and harita[ny][nx] == 1 and not ziyaret_edildi[ny][nx]:
                    # Aradaki hücrenin de geçilebilir olduğunu kontrol et
                    orta_y, orta_x = y + dy//2, x + dx//2
                    if 0 <= orta_y < yukseklik and 0 <= orta_x < genislik and harita[orta_y][orta_x] == 1:
                        ziyaret_edildi[ny][nx] = True
                        yeni_yol = yol + [(x, y)]
                        kuyruk.append((ny, nx, yeni_yol))
        
        # Yol bulunamadı
        return []

class IyiKarakter(Karakter):
    def __init__(self, ad, tur, konum, can=3):
        super().__init__(ad, tur, konum)
        self.can = can
    
    def canAzalt(self):
        self.can -= 1
    
    def canGetir(self):
        return self.can
    
    def canAyarla(self, yeni_can):
        self.can = yeni_can

class LukeSkywalker(IyiKarakter):
    def __init__(self, ad, tur, konum):
        super().__init__(ad, tur, konum, can=3)

class MasterYoda(IyiKarakter):
    def __init__(self, ad, tur, konum):
        super().__init__(ad, tur, konum, can=6)
    
    def canAzalt(self):
        # Master Yoda yarım can kaybeder (0.5 can)
        self.can -= 0.5 